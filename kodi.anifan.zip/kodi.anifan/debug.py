import sys
import os
import json
import urllib
sys.path.append("%s/videosource" % os.path.split(os.path.realpath(__file__))[0])
import adapter1 as src

#print("Debug Via: 22880 -2 -2")
#dat=src.getPlayUrl("22880","2","2")
#print(dat)
